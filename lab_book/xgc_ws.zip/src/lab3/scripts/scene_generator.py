#!/usr/bin/env python3

import rospy
import math
from geometry_msgs.msg import Twist
from visualization_msgs.msg import Marker
from std_msgs.msg import ColorRGBA

class SceneGenerator:
    def __init__(self):
        rospy.init_node('scene_generator', anonymous=True)
        self.cmd_vel_pub_ugv2 = rospy.Publisher('/ugv2/cmd_vel', Twist, queue_size=10)
        self.cmd_vel_pub_ugv1 = rospy.Publisher('/ugv1/cmd_vel', Twist, queue_size=10)
        self.marker_pubs = [
            rospy.Publisher(f'/ugv1/marker_name{i}', Marker, queue_size=10) for i in range(1, 5)
        ]
        
        self.rate = rospy.Rate(10)  # 10Hz 发布频率
        self.t = 0.0
        self.w = 0.5
        self.a = 1.5
        self.r = 3.0
        
        # 预定义障碍物的位置和半径
        self.obstacles = [
            {'x': -6.0, 'y': 22.0, 'radius': 1.5},
            {'x': -3.0, 'y': 16.0, 'radius': 1.5},
            {'x':  4.0, 'y': 22.0, 'radius': 1.5},
            {'x': 9.0, 'y': 16.0, 'radius': 1.5}
        ]

    def generate_figure_eight_velocity(self):
        twist = Twist()
        twist.linear.x = self.a * math.sin(self.w * self.t)  # 控制 x 方向速度
        twist.linear.y = self.a * math.sin(2 * self.w * self.t)  # 控制 y 方向速度
        return twist

    def generate_circle_velocity(self):
        twist = Twist()
        twist.linear.x = self.r * self.w  # 匀速圆周运动 x 方向速度
        twist.angular.z = self.w  # 匀速圆周运动角速度
        return twist

    def publish_markers(self):
        for i, obstacle in enumerate(self.obstacles):
            marker = Marker()
            marker.header.frame_id = "map"
            marker.header.stamp = rospy.Time.now()
            marker.ns = "ugv1"
            marker.id = i
            marker.type = Marker.CYLINDER
            marker.action = Marker.ADD
            marker.pose.position.x = obstacle['x']
            marker.pose.position.y = obstacle['y']
            marker.pose.position.z = 1.5
            marker.scale.x = obstacle['radius'] * 2
            marker.scale.y = obstacle['radius'] * 2
            marker.scale.z = 3.0
            marker.color = ColorRGBA(1.0, 0.2, 0.2, 1.0)  # 浅红色
            marker.lifetime = rospy.Duration()
            self.marker_pubs[i].publish(marker)

    def run(self):
        while not rospy.is_shutdown():
            twist_ugv2 = self.generate_figure_eight_velocity()
            self.cmd_vel_pub_ugv2.publish(twist_ugv2)
            
            twist_ugv1 = self.generate_circle_velocity()
            self.cmd_vel_pub_ugv1.publish(twist_ugv1)
            
            self.publish_markers()
            
            self.t += 0.1  # 时间步长
            self.rate.sleep()

if __name__ == '__main__':
    try:
        scene = SceneGenerator()
        scene.run()
    except rospy.ROSInterruptException:
        pass

